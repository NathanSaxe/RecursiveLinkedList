/*
 * Student.hpp
 *
 *  Created on: Sep 7, 2022
 *      Author: Nathan Saxe
 */

#ifndef STUDENT_HPP_
#define STUDENT_HPP_

#include <string>

using namespace std;

struct Student{
	string data;

	int key;
};




#endif /* STUDENT_HPP_ */
